package com.mindgate.main.services;

import java.util.List;

import com.mindgate.main.domain.Login;

public interface LoginDetailsServiceInterface {

	// To get list of all login details table
	public List<Login> getAllLoginDetails();

	// To insert new login details
	public boolean addNewLoginDetails(Login login);

	// To verify the details from login details table
	public Login verifyLoginDetails(Login login);
}
