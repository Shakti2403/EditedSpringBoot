package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.Login;
import com.mindgate.main.domain.ProjectDetails;

public class EmployeeDetailsRowMapper implements RowMapper<EmployeeDetails> {

	@Override
	public EmployeeDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		Login login = new Login();
		login.setUserId(rs.getInt("user_id"));

		ProjectDetails projectDetails = new ProjectDetails();
		projectDetails.setProjectId(rs.getInt("project_id"));

		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmployeeId(rs.getInt("employee_id"));
		employeeDetails.setFirstName(rs.getString("first_name"));
		employeeDetails.setLastName(rs.getString("last_name"));
		employeeDetails.setContact(rs.getInt("contact"));
		employeeDetails.setDesignation(rs.getString("designation"));
		employeeDetails.setSkill1(rs.getString("skill_1"));
		employeeDetails.setSkill2(rs.getString("skill_2"));
		employeeDetails.setSkill3(rs.getString("skill_3"));
		employeeDetails.setBench(rs.getString("bench"));
		employeeDetails.setSalary(rs.getInt("salary"));
		employeeDetails.setAddress(rs.getString("address"));
		employeeDetails.setCity(rs.getString("city"));
		employeeDetails.setState(rs.getString("state"));
		employeeDetails.setPincode(rs.getInt("pin_code"));
		employeeDetails.setLogin(login);
		employeeDetails.setProjectDetails(projectDetails);

		return employeeDetails;
	}

}
