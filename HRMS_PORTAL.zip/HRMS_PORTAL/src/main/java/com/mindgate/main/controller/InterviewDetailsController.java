package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.InterviewDetails;
import com.mindgate.main.services.InterviewDetailsServiceInterface;

@RestController
@CrossOrigin("*")
@RequestMapping("interviewdetailsapi")
public class InterviewDetailsController {

	@Autowired
	private InterviewDetailsServiceInterface interviewDetailsServiceInterface;

	// http://localhost:8080/interviewdetailsapi/interviewdetails/all
	@RequestMapping(value = "interviewdetails/all", method = RequestMethod.GET)
	public List<InterviewDetails> getAllInterviewDetails() {
		List<InterviewDetails> interviewDetails = interviewDetailsServiceInterface.getAllInterviewDetails();
		return interviewDetails;
	}

	// http://localhost:8080/interviewdetailsapi/insertnewinterviewdetails
	@RequestMapping(value = "insertnewinterviewdetails", method = RequestMethod.POST)
	public InterviewDetails addNewInterviewDetails(@RequestBody InterviewDetails interviewDetails) {
		System.out.println(interviewDetails);
		return interviewDetailsServiceInterface.addNewInterviewDetails(interviewDetails);
	}

	// http://localhost:8080/interviewdetailsapi/updateinterviewdetailsbyinterviewid
	@RequestMapping(value = "updateinterviewdetailsbyinterviewid", method = RequestMethod.PUT)
	public boolean updateInterviewDetails(@RequestBody InterviewDetails interviewDetails) {
		return interviewDetailsServiceInterface.updateInterviewDetails(interviewDetails);
	}

	// http://localhost:8080/interviewdetailsapi/interviewdetailsbystatus/all
	@RequestMapping(value = "interviewdetailsbystatus/all", method = RequestMethod.GET)
	public List<InterviewDetails> getAllInterviewDetailsByStatus() {
		List<InterviewDetails> interviewDetails = interviewDetailsServiceInterface.getAllInterviewDetailsByStatus();
		return interviewDetails;
	}

	// http://localhost:8080/interviewdetailsapi/updateinterviewdetailsstatus
	@RequestMapping(value = "updateinterviewdetailsstatus", method = RequestMethod.PUT)
	public boolean updateInterviewDetailsStatus(@RequestBody InterviewDetails interviewDetails) {
		return interviewDetailsServiceInterface.updateInterviewDetailsStatus(interviewDetails);
	}

	// After interview update status----->SentMail
	// http://localhost:8080/interviewdetailsapi/updateinterviewdetailsstatusformail
	@RequestMapping(value = "updateinterviewdetailsstatusformail", method = RequestMethod.PUT)
	public boolean updateInterviewDetailsStatusForMail(@RequestBody InterviewDetails interviewDetails) {
		return interviewDetailsServiceInterface.updateInterviewDetailsStatusForMail(interviewDetails);
	}
}
