package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.InterviewDetails;

public class InterviewDetailsRowMapper implements RowMapper<InterviewDetails> {

	@Override
	public InterviewDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmployeeId(rs.getInt("employee_id"));

		ApplicantDetails applicantDetails = new ApplicantDetails();
		applicantDetails.setApplicantId(rs.getInt("applicant_id"));

		InterviewDetails interviewDetails = new InterviewDetails();

		interviewDetails.setEmployeeDetails(employeeDetails);
		interviewDetails.setApplicantDetails(applicantDetails);
		interviewDetails.setInterviewId(rs.getInt("interview_id"));

		interviewDetails.setFeedback(rs.getString("feedback"));
		interviewDetails.setStatus(rs.getString("status"));

		return interviewDetails;
	}

}
