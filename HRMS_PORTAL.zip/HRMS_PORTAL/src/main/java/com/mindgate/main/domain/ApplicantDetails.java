package com.mindgate.main.domain;

import java.util.Objects;

public class ApplicantDetails {

	private int applicantId;
	private String applicantName;
	private String mailId;
	private String contactNumber;
	private String skill1;
	private String skill2;
	private String skill3;
	private String qualification;
	private String experience;
	private String status;
	private int jobId;
	private int documentId;

	public ApplicantDetails() {
		// TODO Auto-generated constructor stub
	}

	public ApplicantDetails(int applicantId, String applicantName, String mailId, String contactNumber, String skill1,
			String skill2, String skill3, String qualification, String experience, String status, int jobId,
			int documentId) {
		super();
		this.applicantId = applicantId;
		this.applicantName = applicantName;
		this.mailId = mailId;
		this.contactNumber = contactNumber;
		this.skill1 = skill1;
		this.skill2 = skill2;
		this.skill3 = skill3;
		this.qualification = qualification;
		this.experience = experience;
		this.status = status;
		this.jobId = jobId;
		this.documentId = documentId;
	}

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getSkill1() {
		return skill1;
	}

	public void setSkill1(String skill1) {
		this.skill1 = skill1;
	}

	public String getSkill2() {
		return skill2;
	}

	public void setSkill2(String skill2) {
		this.skill2 = skill2;
	}

	public String getSkill3() {
		return skill3;
	}

	public void setSkill3(String skill3) {
		this.skill3 = skill3;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getDocumentId() {
		return documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	@Override
	public String toString() {
		return "ApplicantDetails [applicantId=" + applicantId + ", applicantName=" + applicantName + ", mailId="
				+ mailId + ", contactNumber=" + contactNumber + ", skill1=" + skill1 + ", skill2=" + skill2
				+ ", skill3=" + skill3 + ", qualification=" + qualification + ", experience=" + experience + ", status="
				+ status + ", jobId=" + jobId + ", documentId=" + documentId + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(applicantId, applicantName, contactNumber, documentId, experience, jobId, mailId,
				qualification, skill1, skill2, skill3, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicantDetails other = (ApplicantDetails) obj;
		return applicantId == other.applicantId && Objects.equals(applicantName, other.applicantName)
				&& Objects.equals(contactNumber, other.contactNumber) && documentId == other.documentId
				&& Objects.equals(experience, other.experience) && jobId == other.jobId
				&& Objects.equals(mailId, other.mailId) && Objects.equals(qualification, other.qualification)
				&& Objects.equals(skill1, other.skill1) && Objects.equals(skill2, other.skill2)
				&& Objects.equals(skill3, other.skill3) && Objects.equals(status, other.status);
	}

}
